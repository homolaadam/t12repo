TSS
import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrls: ['./vizsgafeladat.component.css']
})
export class VizsgafeladatComponent {

  htmlModulErtek:number=1;
  bootstrapModulErtek:number=1;
  javaScriptModulErtek:number=1;
  typeScriptModulErtek:number=1;
  angularModulErtek:number=1;
  serverModulErtek:number=1;

  eredmenyek:string[]=[];
  EredmenyMentes():void{
    this.eredmenyek.push()
  }

}
