//1. feladat

function MegtettUt(sebesseg: number, ido: number): number {
    return (sebesseg * ido);
}
MegtettUt(60, 2)
MegtettUt(120, 3)
MegtettUt(45, 4)

//2. feladat

function HosegriadoSzint(nap1: number, nap2: number, nap3: number): number {
    if (nap1 >= 25) {
        return 1;
    }
    else if (nap1 && nap2 && nap3 >= 26) {
        return 2;
    }
    else if (nap1 && nap2 && nap3 >= 27) {
        return 3;
    }
    else {
        return 0;
    }
}
HosegriadoSzint(29, 27, 30)
HosegriadoSzint(25, 26, 26)
HosegriadoSzint(25, 24, 23)
HosegriadoSzint(21, 24, 23)

//3. feladat

function OszthatoSzamok(oszto: number, vizsgalandoTomb: number[]): number {
    let maradekosOsztokSzama: number = 0;
    for (let i: number = 0; i < vizsgalandoTomb.length; i++) {
        if (vizsgalandoTomb[i] % oszto == 0) {
            maradekosOsztokSzama++;
        }
    }
    return maradekosOsztokSzama;
}
console.log(7, [5, 6, 7, 8, 9, 14, 21])
console.log(2, [4, 6, 7, 8, 10])
console.log(3, [5, 6, 7, 8, 9])

//4. feladat

function Erettsegi(pontok: number[]): [number, number] {
    if (pontok < 39) {
        return 1;
    }
    else if (pontok < 59) {
        return 2;
    }
    else if (pontok < 79) {
        return 3;
    }
    else if (pontok < 119) {
        return 4;
    }
    else {
        return 5;
    }
}

console.log([1, 5, 5, 2, 3])
console.log([15, 30, 15, 45, 30])
console.log([5, 10, 5, 10, 10])
console.log([15, 20, 15, 30, 25])

//5. feladat

function LeetKod(vizsgaltSzoveg: string): string {
    var kicserelendo: string = "i";
    var kicserelt: string = "1";
    for (let i: number = 0; i < vizsgaltSzoveg.length; i++) {
        let cserelniKell: boolean = false;
        for (let j: number = 0; j < kicserelendo.length; j++) {
            if (vizsgaltSzoveg[i] == kicserelendo[j]) {
                cserelniKell = true;
            }
        }
        if (cserelniKell == true) {
            kicserelt += "1";
        }
        else {
            kicserelt += vizsgaltSzoveg[i];
        }
        return kicserelt;
    }
}



console.log("Typescript The Best")
console.log("Szeretem a programozást")
console.log("Almafa")

//6. feladat

interface Snooker {
    ertek: number;
    nev: string;
    orszag: string;
    nyeremeny: number
}

var snookerAdatok: Snooker = {}

function LegtobbNyeremeny(vizsgaltObjektum: array[]): number {

}