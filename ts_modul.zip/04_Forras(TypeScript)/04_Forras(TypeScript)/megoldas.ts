/*A megoldásodat ebben a fájlban készítsd el, majd fordítsd le typeScript compiler segítségével*/
//1. feladat
function KivalasztottBetuk(vizsgaltSzoveg:string, kivalasztottBetuk:number[]):number{

}

//2. feladat
function Szamtani(elsoErtek:number,masodikErtek:number,harmadikErtek:number):boolean{

}

//3.feladat
function VizsgaJegy(osszPont:number):string{
    
}