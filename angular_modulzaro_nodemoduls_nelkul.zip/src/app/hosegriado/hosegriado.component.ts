import { Component } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrls: ['./hosegriado.component.css']
})
export class HosegriadoComponent {
  vizsgaltNap!:number;

  aktualisRiadoSzint():string{
    if(this.vizsgaltNap>25){
      return "1. szintű";
    }
    else if(this.vizsgaltNap>26){
      return "2. szintű";
    }
    else{
      return "3. szintű"
    }
  }

  eredmenyek:string[]=[];
  EredmenyMentes():void{
    this.eredmenyek.push(this.vizsgaltNap+" "+this.aktualisRiadoSzint())
  }
}
