//Ide illessze be a JavasScript kódot a teszteléshez
/*

1. feladat

function OsztokSzama(vizsgaltSzam){
let osztokSzama=0;
for(let i=1;i<vizsgaltSzam;i++){
    if(vizsgaltSzam%2==0)
        return osztokSzama
}
}*/
function OsztokSzama(vizsgaltSzam){
    let vizsgalandoSzam=0;
if(vizsgaltSzam%vizsgalandoSzam==0){
return true;
}
else{
return false;
}
}
document.write(+OsztokSzama(4,3));

//2. feladat

function ParatlanLista(vizsgaltTomb){

}


//3. feladat

function VizsgaEredmeny(nev){
    
}